package com.medsupply.auth_service.dto.request;

import com.medsupply.auth_service.entity.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record RegisterRequest(
        String name,

        @Size(max = 60, message = "First name must be at most 60 characters")
        String firstName,

        @Size(max = 60, message = "Second name must be at most 60 characters")
        String lastName,

        @Size(max = 150, message = "Hospital name must be at most 150 characters")
        String hospitalName,

        @NotBlank(message = "Email is required")
        @Email(message = "Invalid email format")
        String email,

        @Email(message = "Invalid confirm email format")
        String confirmEmail,

        @NotBlank(message = "Password is required")
        @Size(min = 6, message = "Password must be at least 6 characters")
        String password,

        @NotNull(message = "Role is required")
        Role role
) {}