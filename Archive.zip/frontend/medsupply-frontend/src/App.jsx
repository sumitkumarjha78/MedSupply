import { useCallback, useEffect, useMemo, useState } from 'react';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { productApi, inventoryApi, orderApi } from './api/medsupplyApi';
import LandingPage from './components/LandingPage';
import AuthPage from './components/AuthPage';
import Navbar from './components/Navbar';
import CatalogView from './components/CatalogView';
import InventoryView from './components/InventoryView';
import OrdersView from './components/OrdersView';
import CartDrawer from './components/CartDrawer';

function DashboardShell() {
  const { user, loading } = useAuth();
  const [authScreen, setAuthScreen] = useState(null); // null | 'login' | 'register'
  const [activeTab, setActiveTab] = useState('catalog');
  const [products, setProducts] = useState([]);
  const [inventoryList, setInventoryList] = useState([]);
  const [orders, setOrders] = useState([]);
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [toast, setToast] = useState(null);

  const notify = useCallback((type, message) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  }, []);

  const syncAllData = useCallback(async () => {
    if (!user) return;
    setRefreshing(true);
    try {
      const canReadOrders = user.role === 'HOSPITAL_BUYER' || user.role === 'ADMIN';
      const [prodData, invData, ordData] = await Promise.all([
        productApi.getAll(),
        inventoryApi.getAll(),
        canReadOrders ? orderApi.getAll() : Promise.resolve([]),
      ]);
      setProducts(Array.isArray(prodData) ? prodData : []);
      setInventoryList(Array.isArray(invData) ? invData : []);
      setOrders(Array.isArray(ordData) ? ordData : []);
    } catch (err) {
      notify('error', `Could not refresh data: ${err.message}`);
    } finally {
      setRefreshing(false);
    }
  }, [user, notify]);

  useEffect(() => {
    if (user) {
      setAuthScreen(null);
      setActiveTab('catalog');
      syncAllData();
    } else {
      setCart([]);
      setProducts([]);
      setInventoryList([]);
      setOrders([]);
    }
  }, [user, syncAllData]);

  const inventoryMap = useMemo(() => {
    const map = {};
    inventoryList.forEach((item) => {
      map[item.productId] = item;
    });
    return map;
  }, [inventoryList]);

  const productLookup = useMemo(() => {
    const map = {};
    products.forEach((p) => {
      map[p.id] = p;
    });
    return map;
  }, [products]);

  const handleAddToCart = (product) => {
    const maxStock = inventoryMap[product.id]?.availableQuantity ?? 0;
    setCart((prev) => {
      const existing = prev.find((c) => c.product.id === product.id);
      if (existing) {
        if (existing.quantity >= maxStock) return prev;
        return prev.map((c) =>
          c.product.id === product.id ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    notify('success', `Added ${product.productName} to cart`);
  };

  const handleUpdateQty = (productId, newQty) => {
    if (newQty <= 0) {
      setCart((prev) => prev.filter((c) => c.product.id !== productId));
      return;
    }
    setCart((prev) =>
      prev.map((c) => (c.product.id === productId ? { ...c, quantity: newQty } : c))
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC] text-slate-500 text-sm font-medium">
        Loading your workspace...
      </div>
    );
  }

  if (!user) {
    if (authScreen) {
      return (
        <AuthPage
          initialMode={authScreen}
          onBack={() => setAuthScreen(null)}
        />
      );
    }
    return <LandingPage onNavigateAuth={(mode) => setAuthScreen(mode)} />;
  }

  const isInternalStaff = user.role === 'ADMIN' || user.role === 'INVENTORY_MANAGER';
  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={totalCartItems}
        onOpenCart={() => setCartOpen(true)}
        onRefresh={syncAllData}
        refreshing={refreshing}
      />

      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 max-w-sm">
          <div
            className={`flex items-center gap-3 px-4 py-3 rounded-xl shadow-lg border text-sm font-medium ${
              toast.type === 'success'
                ? 'bg-slate-900 text-white border-slate-800'
                : 'bg-rose-600 text-white border-rose-500'
            }`}
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-white shrink-0" />
            )}
            <span className="flex-1">{toast.message}</span>
            <button
              onClick={() => setToast(null)}
              className="opacity-70 hover:opacity-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'catalog' && (
          <CatalogView
            products={products}
            inventoryMap={inventoryMap}
            role={user.role}
            cart={cart}
            onAddToCart={handleAddToCart}
            onDataChanged={syncAllData}
            notify={notify}
          />
        )}

        {activeTab === 'inventory' && isInternalStaff && (
          <InventoryView
            products={products}
            inventoryList={inventoryList}
            role={user.role}
            onDataChanged={syncAllData}
            notify={notify}
          />
        )}

        {activeTab === 'orders' && (
          <OrdersView
            orders={orders}
            productLookup={productLookup}
            onDataChanged={syncAllData}
            notify={notify}
          />
        )}
      </main>

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        inventoryMap={inventoryMap}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={(id) => setCart((prev) => prev.filter((c) => c.product.id !== id))}
        onClearCart={() => setCart([])}
        onOrderSuccess={async () => {
          await syncAllData();
          setActiveTab('orders');
        }}
        notify={notify}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DashboardShell />
    </AuthProvider>
  );
}