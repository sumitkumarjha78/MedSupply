import axios from 'axios';

const axiosClient = axios.create({
  baseURL: 'http://localhost:8080',
  headers: {
    'Content-Type': 'application/json',
  },
});

axiosClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('medsupply_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

axiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const fieldErrors = error.response?.data?.errors || error.response?.data?.fieldErrors;
    const fieldMsg =
      fieldErrors && typeof fieldErrors === 'object'
        ? Object.values(fieldErrors).join(', ')
        : null;

    const serverMsg =
      fieldMsg ||
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.message ||
      'Unexpected server error';

    if (error.response?.status === 401 && !error.config?.url?.includes('/api/auth/')) {
      localStorage.removeItem('medsupply_token');
      localStorage.removeItem('medsupply_user');
      window.dispatchEvent(new Event('medsupply:unauthorized'));
    }

    return Promise.reject(new Error(serverMsg));
  }
);

export default axiosClient;